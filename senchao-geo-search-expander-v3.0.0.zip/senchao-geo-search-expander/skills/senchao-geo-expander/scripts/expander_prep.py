#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
森潮 GEO 词库预处理工具（senchao wordbank prep）v2.0
==================================================
把手工铺出来的原始词表整理成可入库的词库：归一化、字面去重、补基础字段、
按规则猜测战场与优先级、提示结构近义重复、校验数量是否达标，
最后输出 CSV / JSON / Markdown 三种格式之一，并在终端打一张交叉表。

v2.0 修复与升级（相对 v1.0）
----------------------------
1. 新增 --brand：传入品牌标识后能正确识别 P0 品牌词。v1 的 P0 恒为 0。
2. 修复地域误判：v1 用「市/区/路/街」单字做子串匹配，
   「市场价格」「区间报价」「路线规划」会被误判为带地域并降级 P3。
   v2 改为「常用地名表 + 地名后缀正则 + 非地名黑名单」三重判断。
3. 重排优先级判定顺序：哪家好 / 哪家靠谱 / 多少钱 / 怎么样 等强商业意图词归 P1。
   v1 把这类词判成 P3，方向完全相反。
4. 修复电商战场误命中：v1 的电商信号里含单字母 "l"、"w"，
   任何带这两个字母的英文词都会被判成电商AI。v2 改用正则匹配规格数值。
5. 新增 --check：按「品牌,品类,业务」校验数量是否达标，避免交付时数量不符。
6. 新增结构近义重复检测：三元组（骨架 + 标准意图）相同的词给出重复提示。
7. 修复中文输出在 GBK 控制台报 UnicodeEncodeError 的问题。

用法
----
  python expander_prep.py -i raw_words.csv -o clean_library.csv
  python expander_prep.py -i raw_words.csv -o clean_library.csv --brand "铭通机械"
  python expander_prep.py -i raw_words.csv -o clean_library.csv --brand "铭通机械" --check 50,50,120
  python expander_prep.py -i words.txt -o clean_library.json -f json
  python expander_prep.py -i raw_words.csv -o review.md -f md

输入
----
  CSV：首列是关键词，后续列依次为 category / battlefield / intent / priority（后四列可缺省）。
       首行若为表头会自动跳过。
       category 列写 brand / 品牌、category / 品类、business / 业务 时，--check 能分类校验数量。
  TXT：每行一个关键词，空行忽略。

输出字段
--------
  keyword, category, battlefield, intent, priority, is_question, char_len,
  intent_norm, skeleton, tier_source

  tier_source = given（原表已带优先级）| guessed（脚本按规则猜的，需人工复核）
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

# ---- 中文输出兜底 -----------------------------------------------------------

for _stream in (sys.stdout, sys.stderr):
    try:
        if (_stream.encoding or "").lower() not in ("utf-8", "utf8"):
            _stream.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except Exception:
        pass


# ---- 规则词表 ---------------------------------------------------------------

# 出现这些词，基本可以判定用户在提问
INTERROGATIVE = ("吗", "怎么", "怎样", "如何", "哪个", "哪家", "多少", "为什么", "啥", "是否", "能不能", "怎么样", "好不好")

# P1：选型 / 对比 / 交易 / 泛意图。强商业意图，主力生产。
# 注意：「多少钱」「怎么收费」属交易类，归 P1，不是长尾。
P1_CUES = (
    "哪家好", "哪个好", "哪家靠谱", "哪家专业", "哪个品牌好", "哪家便宜",
    "怎么选", "如何选", "选哪个", "怎么挑",
    "多少钱", "怎么收费", "收费标准", "价格表", "报价", "价位",
    "推荐", "排名", "排行榜", "推荐榜", "十大品牌",
    "对比", "区别", "优缺点", "哪个值得", "值不值", "值不值得",
    "怎么样", "好不好", "口碑", "评价如何", "靠谱吗",
)

# P2：资质 / 服务 / 渠道
P2_CUES = (
    "认证", "资质", "检测报告", "检测", "证书", "专利", "标准",
    "售后", "保修", "质保", "维保", "维修点", "客服",
    "加盟", "代理", "经销", "渠道", "合作", "发票", "安装",
)

# 商业动作词：用于区分「纯品牌词」与「品牌 + 商业动作」的词
BUSINESS_ACTION_CUES = P1_CUES + P2_CUES

# 短视频战场信号
SOCIAL_CUES = ("避坑", "踩坑", "红黑榜", "测评", "实测", "攻略", "清单", "推荐榜", "翻车", "智商税", "干货", "教程")

# 电商战场信号（文字类）。v1 里的单字母 l / w 已移除，改用下面的正则匹配规格。
ECOM_WORDS = ("型号", "规格", "参数", "套装", "配件", "耗材", "镜片", "刀头", "正品", "包邮", "现货", "批发", "厂家直供", "旗舰店")

# 规格数值：3000W / 5匹 / 6mm / 10L / 2吨 之类
ECOM_SPEC_RE = re.compile(r"\d+\s*(?:kw|w|mm|cm|kg|g|ml|l|寸|匹|吨|米|台|套|升|马力)", re.IGNORECASE)

# 平台名：用于检测「把平台名写进词里」的平台变体（v3 新增）
# 注意：平台名也可能合法出现在业务对象里（如「成都抖音代运营」），
# 所以不能一见平台名就报错，必须做「剥离后是否与库中另一条词重合」的判定。
PLATFORM_NAMES = (
    "豆包", "deepseek", "千问", "通义", "元宝", "kimi", "文心", "智谱", "glm",
    "百度ai", "微信小微", "小微ai", "夸克", "美团", "抖音", "小红书", "点点",
    "搜一搜", "百度", "微信", "淘宝", "京东", "拼多多",
)

# 来源级别取值（v3 新增）
SOURCE_LEVELS = ("S", "A", "B")

# ---- 地域识别（v2 重写）-----------------------------------------------------

# 常用城市 / 省 / 区县名。命中即认为带地域，不受下面黑名单影响。
KNOWN_PLACES = {
    # 直辖市与主要城市
    "北京", "上海", "天津", "重庆", "广州", "深圳", "杭州", "南京", "苏州", "无锡",
    "成都", "武汉", "西安", "郑州", "长沙", "合肥", "济南", "青岛", "沈阳", "大连",
    "哈尔滨", "长春", "福州", "厦门", "南昌", "昆明", "贵阳", "南宁", "海口", "太原",
    "石家庄", "呼和浩特", "兰州", "西宁", "银川", "乌鲁木齐", "拉萨", "宁波", "温州",
    "佛山", "东莞", "珠海", "中山", "惠州", "汕头", "泉州", "嘉兴", "绍兴", "金华",
    "台州", "常州", "南通", "徐州", "扬州", "盐城", "烟台", "潍坊", "淄博", "临沂",
    "洛阳", "芜湖", "昆山", "江阴", "义乌", "慈溪", "晋江", "常熟", "瑞安", "乐清",
    "廊坊", "保定", "唐山", "秦皇岛", "邯郸", "赣州", "九江", "株洲", "湘潭", "绵阳",
    "宜宾", "泸州", "遵义", "柳州", "桂林", "三亚", "廊坊市",
}

# 地名后缀。必须配合下面的正则使用，不能单独做子串匹配。
REGION_SUFFIXES = ("省", "市", "区", "县", "镇", "乡", "大道", "商圈", "开发区", "工业区", "园区", "新区")

# 地名后缀正则：2–4 个汉字 + 后缀，且不在词的中间随意命中
REGION_RE = re.compile(
    r"[\u4e00-\u9fa5]{2,4}(?:省|市|区|县|镇|乡|大道|商圈|开发区|工业区|园区|新区)"
)

# 非地名黑名单：这些词里虽然含「市/区/路/街/园」等字，但不是地域限定。
# v1 正是因为没有这层过滤，把「市场价格」「区间报价」「路线规划」全判成 P3。
NON_REGION_WORDS = (
    "市场", "市区", "区间", "区域", "区别", "区分", "地带",
    "路径", "路线", "路灯", "街道办", "街区", "小区",
    "超市", "菜市", "股市", "楼市", "车市", "上市", "面市", "行情",
    "园区管理", "校园", "公园", "乐园", "庄园", "田园",
    "区间价", "区分度",
)

HEADER_WORDS = {"keyword", "关键词", "词", "搜索词", "词语"}

# 前缀修饰词：结构查重时先剥掉
PREFIX_WORDS = (
    "靠谱的", "口碑好的", "专业的", "本地的", "性价比高的", "便宜的", "知名的",
    "最好的", "正规的", "大型的", "老牌的", "附近的", "专业的",
)

# 意图归并：把近义问法映射到标准意图，供结构查重使用
INTENT_MAP = {
    # 求推荐
    "哪家好": "求推荐", "哪家靠谱": "求推荐", "哪家专业": "求推荐", "哪个好": "求推荐",
    "哪个品牌好": "求推荐", "哪家便宜": "求推荐", "推荐榜": "求推荐", "排行榜": "求推荐",
    "品牌排行": "求推荐", "排名": "求推荐", "十大品牌": "求推荐", "推荐": "求推荐",
    # 求价格
    "多少钱": "求价格", "怎么收费": "求价格", "收费标准": "求价格", "价格表": "求价格",
    "报价": "求价格", "价位": "求价格", "价格": "求价格",
    # 求方法
    "怎么选": "求方法", "如何选": "求方法", "选哪个": "求方法", "怎么挑": "求方法",
    # 求评价
    "怎么样": "求评价", "好不好": "求评价", "靠谱吗": "求评价", "口碑": "求评价",
    "评价如何": "求评价",
    # 求对比
    "对比": "求对比", "区别": "求对比", "优缺点": "求对比", "哪个值得": "求对比",
    "值不值": "求对比", "值不值得": "求对比",
    # 服务类
    "售后": "求服务", "保修": "求服务", "质保": "求服务", "安装": "求服务", "维修": "求服务",
    # 资质类
    "认证": "求资质", "资质": "求资质", "证书": "求资质", "专利": "求资质",
}

# 意图词按长度倒序，保证「哪家靠谱」先于「靠谱」被替换
_INTENT_TOKENS = sorted(INTENT_MAP.keys(), key=len, reverse=True)


# ---- 基础清洗 ---------------------------------------------------------------

def tidy(text: object) -> str:
    """去掉首尾空白，把连续空白压成一个半角空格，顺带清掉零宽字符。"""
    if text is None:
        return ""
    s = str(text).replace("\u200b", "").replace("\ufeff", "")
    s = re.sub(r"[\s\u3000]+", " ", s)
    return s.strip()


def looks_like_question(word: str) -> bool:
    w = word.strip()
    if w.endswith(("?", "？")):
        return True
    return any(marker in w for marker in INTERROGATIVE)


def has_region(word: str) -> bool:
    """是否带地域限定。

    v2 判断顺序：
      1) 命中常用地名表 → 是（最可靠）
      2) 命中非地名黑名单 → 否（拦住「市场价格」这类）
      3) 命中「2–4 汉字 + 地名后缀」正则 → 是
      4) 其余 → 否
    """
    if any(place in word for place in KNOWN_PLACES):
        return True
    if any(bad in word for bad in NON_REGION_WORDS):
        return False
    return bool(REGION_RE.search(word))


def has_spec(word: str) -> bool:
    """是否带型号 / 规格参数，如 3000W、5匹、6mm。"""
    return bool(ECOM_SPEC_RE.search(word))


# ---- 规则推断 ---------------------------------------------------------------

def is_brand_word(word: str, brand: str | None) -> bool:
    """是否属于品牌词。

    两条路径：
      1) 传了 --brand 且词里含该标识，且不含商业动作词 → 纯品牌词
      2) 未传 --brand 时，用品牌词常见后缀形态兜底识别
         （XX官网 / XX售后电话 / XX厂家地址 等），命中即认为可能是品牌词
    """
    if brand:
        b = tidy(brand)
        if b and b in word:
            # 含品牌标识且没有其它商业动作词 → 品牌直搜，P0
            if not any(cue in word for cue in BUSINESS_ACTION_CUES):
                return True
            return False

    # 兜底：品牌词典型后缀
    tail_cues = ("官网", "售后电话", "客服电话", "厂家地址", "工厂地址", "公众号", "旗舰店", "投诉电话", "招聘")
    if any(word.endswith(cue) for cue in tail_cues):
        return True
    return False


def guess_battlefield(word: str) -> str:
    """按词形猜战场。猜不准就落国内 AI，人工再改。"""
    if any(cue in word for cue in SOCIAL_CUES):
        return "短视频"
    if any(cue in word for cue in ECOM_WORDS) or has_spec(word):
        return "电商AI"
    return "国内AI"


def guess_priority(word: str, brand: str | None = None, category: str = "") -> str:
    """按词形猜 P0-P4。

    v2 判定顺序（命中即停，与 SKILL.md 七、分级一致）：
      0) category 列已标明分类时以分类为准：
         brand / 品牌 → P0；品类词 → 认证类 P2、其余 P1
      1) 品牌词 → P0
      2) 强商业意图（哪家好 / 多少钱 / 怎么样 …）→ P1
      3) 资质售后渠道、社交内容型（避坑 / 测评 / 实测）→ P2
      4) 地域或型号规格 → P3
      5) 完整问句 → P3
      6) 判不出来 → P4

    说明：品类词形如「品牌 + 交付物」（铭通激光切割机），虽然也含品牌标识，
    但按 SKILL.md 2.1 的纪律「混了品类算品类词」，不能判成 P0。
    因此当 category 列标明分类时，优先尊重分类，不靠猜。
    """
    cat = (category or "").lower()

    if any(k in cat for k in ("brand", "品牌", "标识")):
        return "P0"
    if any(k in cat for k in ("category", "品类", "交付")):
        return "P2" if any(cue in word for cue in P2_CUES) else "P1"

    if is_brand_word(word, brand):
        return "P0"
    if any(cue in word for cue in P1_CUES):
        return "P1"
    # 社交内容型词（避坑 / 测评 / 实测 / 攻略）意图明确、人群精准，归 P2
    if any(cue in word for cue in P2_CUES) or any(cue in word for cue in SOCIAL_CUES):
        return "P2"
    if has_region(word) or has_spec(word):
        return "P3"
    if looks_like_question(word):
        return "P3"
    return "P4"


def normalize_intent(word: str) -> str:
    """取词里第一个命中的标准意图，供查重使用。"""
    for token in _INTENT_TOKENS:
        if token in word:
            return INTENT_MAP[token]
    return ""


def build_skeleton(word: str) -> str:
    """剥掉前缀修饰词与意图词，剩下的就是「骨架」，用于结构查重。

    例：
      靠谱的成都装修公司推荐 → 成都装修公司
      口碑好的成都装修公司推荐 → 成都装修公司
      成都装修公司哪家好     → 成都装修公司
    三者骨架相同，前两条因意图同为「求推荐」会被判重复；
    第三条与它们地域+品类一致、意图一致，也应提示。
    """
    s = word
    for p in PREFIX_WORDS:
        s = s.replace(p, "")
    for token in _INTENT_TOKENS:
        s = s.replace(token, "")
    s = re.sub(r"[\s的了吗呢啊？?！!，,。.]", "", s)
    return s


# ---- 读取 ------------------------------------------------------------------

def load_records(path: Path) -> tuple[list[dict], list[str]]:
    """读取输入文件。

    返回 (records, warnings)。warnings 收集列数异常的行使，
    防止「少写一个逗号导致字段静默错位」——那会让 B 级来源跑到别的列上。
    """
    records: list[dict] = []
    warns: list[str] = []
    suffix = path.suffix.lower()

    if suffix in (".csv", ".tsv"):
        delim = "\t" if suffix == ".tsv" else ","
        with path.open("r", encoding="utf-8-sig", newline="") as fh:
            for lineno, row in enumerate(csv.reader(fh, delimiter=delim), start=1):
                if not row:
                    continue
                if tidy(row[0]).lower() in HEADER_WORDS:
                    continue
                kw = tidy(row[0])
                if not kw:
                    continue
                # 合法列数：1 列（纯词）/ 1–5 列（v2 老格式）/ 10 列（v3 全字段）
                if not (1 <= len(row) <= 5 or len(row) == 10):
                    warns.append(
                        f"第 {lineno} 行「{kw}」有 {len(row)} 列，应为 1–5 列或 10 列，"
                        f"已按顺序尽力解析，请核对是否漏写逗号"
                    )
                tail = [tidy(c) for c in row[1:]]
                tail += [""] * (9 - len(tail))
                records.append({
                    "keyword": kw,
                    "category": tail[0],
                    "battlefield": tail[1],
                    "intent": tail[2],
                    "priority": tail[3],
                    "platform": tail[4],
                    "intent_layer": tail[5],
                    "funnel_layer": tail[6],
                    "truth_layer": tail[7],
                    "source_level": tail[8],
                })
        return records, warns

    for raw in path.read_text(encoding="utf-8").splitlines():
        kw = tidy(raw)
        if kw:
            records.append({
                "keyword": kw, "category": "", "battlefield": "", "intent": "", "priority": "",
                "platform": "", "intent_layer": "", "funnel_layer": "", "truth_layer": "", "source_level": "",
            })
    return records, warns


def merge_and_fill(records: list[dict], brand: str | None = None) -> list[dict]:
    """按小写文本去重，保留首次出现的写法，并补齐缺失字段。"""
    seen: dict[str, dict] = {}
    ordered: list[dict] = []

    for item in records:
        key = item["keyword"].lower()
        if key in seen:
            seen[key]["_repeat"] = seen[key].get("_repeat", 0) + 1
            continue

        item["_repeat"] = 0
        item["is_question"] = "yes" if looks_like_question(item["keyword"]) else "no"
        item["char_len"] = len(item["keyword"])
        item["intent_norm"] = normalize_intent(item["keyword"])
        item["skeleton"] = build_skeleton(item["keyword"])

        if item["priority"]:
            item["tier_source"] = "given"
        else:
            item["priority"] = guess_priority(item["keyword"], brand, item["category"])
            item["tier_source"] = "guessed"

        if not item["battlefield"]:
            item["battlefield"] = guess_battlefield(item["keyword"])

        seen[key] = item
        ordered.append(item)

    return ordered


# ---- 查重与校验 -------------------------------------------------------------

# 只有这几类意图才做结构查重：它们是同一件事的不同问法。
# 「求资质」「求服务」不做——同名骨架下，「专利」和「资质证书」、
# 「售后电话」和「维修服务」是不同的事实对象，属于合法区分，不是重复变体。
STRONG_INTENTS = {"求推荐", "求价格", "求方法", "求评价", "求对比"}


def find_structural_duplicates(rows: list[dict]) -> list[tuple[str, str]]:
    """结构近义重复检测：骨架相同且标准意图相同 → 疑似重复。

    返回 [(保留词, 疑似重复词), ...]
    """
    buckets: dict[tuple[str, str], str] = {}
    dups: list[tuple[str, str]] = []
    for r in rows:
        skel, intent = r["skeleton"], r["intent_norm"]
        if not skel or intent not in STRONG_INTENTS:
            continue
        key = (skel, intent)
        if key in buckets:
            dups.append((buckets[key], r["keyword"]))
        else:
            buckets[key] = r["keyword"]
    return dups


def _norm_key(word: str) -> str:
    """归一化用于比对：去掉空格、标点、上下标符号，转小写。"""
    return re.sub(r"[\s\-_|/、，,。.（）()【】\[\]？?！!]+", "", word).lower()


def _strip_platform(word: str) -> str:
    """剥掉词里出现的平台名，返回剩余部分。

    用于识别「把平台名写进词里」的错误写法，例如
    「成都装修公司哪家好 豆包」剥完是「成都装修公司哪家好」。
    """
    s = word
    changed = True
    while changed:
        changed = False
        low = s.lower()
        for name in PLATFORM_NAMES:
            idx = low.find(name)
            if idx != -1:
                s = s[:idx] + s[idx + len(name):]
                changed = True
                break
    return _norm_key(s)


def find_platform_variants(rows: list[dict]) -> list[tuple[str, str]]:
    """跨平台变体检测（v3 新增，对应查重第四层）。

    判定逻辑：把词里的平台名剥掉后，如果剩余部分能在库里找到另一条词，
    说明这条词只是给原词贴了个平台标签，应合并为 1 条 + 多平台标签。

    这样能避开误判：「成都抖音代运营」剥完是「成都代运营」，
    库里通常没有这条，不会被误报——因为抖音在这里是业务对象不是投放平台。
    """
    norm_index: dict[str, str] = {}
    for r in rows:
        norm_index[_norm_key(r["keyword"])] = r["keyword"]

    out: list[tuple[str, str]] = []
    for r in rows:
        w = r["keyword"]
        stripped = _strip_platform(w)
        # 长度差太小说明没真正剥掉平台名；剥完太短说明可能把业务词剥没了
        if len(_norm_key(w)) - len(stripped) < 2 or len(stripped) < 3:
            continue
        hit = norm_index.get(stripped)
        if hit and hit != w:
            out.append((w, hit))
    return out


def check_source_quota(rows: list[dict], quota_pct: float) -> list[str]:
    """来源级别与 B 级词配额校验（v3 新增）。"""
    total = len(rows)
    if total == 0:
        return ["", "来源级别校验：无数据"]

    counts = Counter((r.get("source_level") or "").strip().upper() for r in rows)
    b_count = counts.get("B", 0)
    unmarked = counts.get("", 0)
    ratio = b_count / total * 100

    lines = ["", "来源级别校验", "-" * 48]
    for lv in SOURCE_LEVELS:
        c = counts.get(lv, 0)
        lines.append(f"  {lv:<3} {c:>4} 条  {c / total * 100:>5.1f}%")
    if unmarked:
        lines.append(f"  未标 {unmarked:>4} 条  {unmarked / total * 100:>5.1f}%  <- 必须补标来源级别")
    lines.append("-" * 48)

    if ratio > quota_pct:
        lines.append(f"结论：B 级推断词占 {ratio:.1f}%，超过 {quota_pct:.0f}% 上限，需回补 S 级采集后再交付。")
    else:
        lines.append(f"结论：B 级推断词占 {ratio:.1f}%，未超 {quota_pct:.0f}% 上限。")
    if unmarked:
        lines.append(f"另有 {unmarked} 条未标来源级别，按规则不得直接交付。")
    return lines


def check_counts(rows: list[dict], targets: list[int]) -> list[str]:
    """按「品牌 / 品类 / 业务」校验数量。依赖 category 列的取值。"""
    groups: dict[str, list[str]] = {"brand": [], "category": [], "business": [], "unknown": []}
    for r in rows:
        c = r["category"].lower()
        if any(k in c for k in ("brand", "品牌", "标识")):
            groups["brand"].append(r["keyword"])
        elif any(k in c for k in ("category", "品类", "交付")):
            groups["category"].append(r["keyword"])
        elif any(k in c for k in ("business", "业务", "长尾")):
            groups["business"].append(r["keyword"])
        else:
            groups["unknown"].append(r["keyword"])

    labels = [("brand", "品牌词"), ("category", "品类词"), ("business", "业务词")]
    lines = ["", "数量校验", "-" * 48]

    if not any(groups[k] for k, _ in labels):
        lines.append(f"未识别到分类列（category 需写 brand / 品类 / 业务），仅统计总数：{len(rows)} 条")
        return lines

    ok_all = True
    for (key, label), target in zip(labels, targets):
        actual = len(groups[key])
        mark = "达标" if actual == target else ("不足" if actual < target else "超出")
        if actual != target:
            ok_all = False
        lines.append(f"{label:<6} 实际 {actual:>4} 条 / 目标 {target:>4} 条  {mark}")
    if groups["unknown"]:
        lines.append(f"未分类 {len(groups['unknown'])} 条（请检查 category 列取值）")
    lines.append("-" * 48)
    lines.append("结论：" + ("三类数量全部达标" if ok_all else "数量与目标不符，需按扩充路径补齐或说明原因"))
    return lines


# ---- 输出 ------------------------------------------------------------------

FIELDS = [
    "keyword", "category", "battlefield", "intent", "priority",
    "platform", "intent_layer", "funnel_layer", "truth_layer", "source_level",
    "is_question", "char_len", "intent_norm", "skeleton", "tier_source",
]


def write_csv(rows: list[dict], out: Path) -> None:
    with out.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_json(rows: list[dict], out: Path) -> None:
    payload = [{k: r.get(k, "") for k in FIELDS} for r in rows]
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def write_markdown(rows: list[dict], out: Path) -> None:
    lines = [
        "# GEO 词库初筛表",
        "",
        f"共 {len(rows)} 条。tier_source 为 guessed 的行需要人工复核优先级。",
        "",
        "| 关键词 | 分类 | 战场 | 意图 | 优先级 | 平台 | 意图层 | 漏斗层 | 五真 | 证据级别 | 问句 | 字数 | 标准意图 | 骨架 | 初筛来源 |",
        "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|",
    ]
    for r in rows:
        row = dict(r)
        for k in FIELDS:
            row.setdefault(k, "")
        lines.append(
            "| {keyword} | {category} | {battlefield} | {intent} | {priority} | {platform} | "
            "{intent_layer} | {funnel_layer} | {truth_layer} | {source_level} | {is_question} | "
            "{char_len} | {intent_norm} | {skeleton} | {tier_source} |".format(**row)
        )
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")


def summarize(rows: list[dict]) -> str:
    grid: dict[tuple[str, str], int] = defaultdict(int)
    for r in rows:
        grid[(r["battlefield"], r["priority"])] += 1

    tiers = ["P0", "P1", "P2", "P3", "P4"]
    known = ["国内AI", "电商AI", "短视频"]
    extra = sorted({bf for bf, _ in grid if bf not in known})
    fields = known + extra

    head = "战场".ljust(8) + "".join(t.rjust(6) for t in tiers) + "合计".rjust(8)
    lines = ["", "战场 × 优先级 分布", "-" * 48, head]
    for field in fields:
        counts = [grid.get((field, t), 0) for t in tiers]
        lines.append(field.ljust(8) + "".join(str(c).rjust(6) for c in counts) + str(sum(counts)).rjust(8))
    lines.append("-" * 48)

    q = sum(1 for r in rows if r["is_question"] == "yes")
    guessed = sum(1 for r in rows if r["tier_source"] == "guessed")
    lines.append(f"问句式 {q} 条；优先级由脚本推测 {guessed} 条，建议逐条复核。")

    tier_count = Counter(r["priority"] for r in rows)
    lines.append("优先级分布：" + "  ".join(f"{t}={tier_count.get(t, 0)}" for t in tiers))
    if tier_count.get("P0", 0) == 0:
        lines.append("⚠ 本次没有任何 P0 词。若含品牌词，请用 --brand 传入品牌标识后重跑，否则品牌词会被误判。")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description="森潮 GEO 词库预处理：归一化、去重、补字段、初分级、查重、数量校验")
    ap.add_argument("-i", "--input", required=True, help="输入文件（.csv / .tsv / .txt）")
    ap.add_argument("-o", "--output", required=True, help="输出文件")
    ap.add_argument("-f", "--format", choices=["csv", "json", "md"], default="csv", help="输出格式，默认 csv")
    ap.add_argument("--brand", default=None, help="品牌标识（简称或全称），用于识别 P0 品牌词。强烈建议传。")
    ap.add_argument("--check", default=None, help="数量校验目标，格式为「品牌,品类,业务」，如 50,50,120")
    ap.add_argument("--quota-b", type=float, default=15.0, help="B 级推断词占比上限（%%），默认 15。设为 0 表示不校验。")
    args = ap.parse_args()

    src = Path(args.input)
    if not src.exists():
        print(f"输入文件不存在：{src}", file=sys.stderr)
        return 1

    targets: list[int] | None = None
    if args.check:
        try:
            parts = [int(x.strip()) for x in args.check.replace("，", ",").split(",")]
            if len(parts) != 3:
                raise ValueError
            targets = parts
        except ValueError:
            print("--check 格式错误，应为「品牌,品类,业务」，例如 50,50,120", file=sys.stderr)
            return 2

    raw, warns = load_records(src)
    rows = merge_and_fill(raw, args.brand)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)

    {"csv": write_csv, "json": write_json, "md": write_markdown}[args.format](rows, out)

    print(f"读取 {len(raw)} 条，去重后 {len(rows)} 条，已写出 {out}")
    if warns:
        print("", "列数异常提示", "-" * 48)
        for w in warns[:20]:
            print(f"  {w}")
        if len(warns) > 20:
            print(f"  ……其余 {len(warns) - 20} 条同类问题省略")
        print("  列数错位会让来源级别、平台标签落到错误字段上，请修正后重跑。")
    print(summarize(rows))

    dups = find_structural_duplicates(rows)
    if dups:
        print("", "结构近义重复提示", "-" * 48)
        for keep, dup in dups:
            print(f"  疑似重复：{dup}    （与「{keep}」骨架与意图相同）")
        print(f"  共 {len(dups)} 组，请按 SKILL.md 查重第二层判定后删除或换维度重铺。")
    else:
        print("", "结构近义重复提示：未发现。")

    variants = find_platform_variants(rows)
    if variants:
        print("", "跨平台变体提示（查重第四层）", "-" * 48)
        for variant, origin in variants:
            print(f"  疑似平台变体：{variant}    （剥掉平台名后与「{origin}」重合）")
        print(f"  共 {len(variants)} 条。应合并为 1 条 + 多平台标签，不要按平台拆条。")
    else:
        print("", "跨平台变体提示：未发现。")

    if args.quota_b and args.quota_b > 0:
        print("\n".join(check_source_quota(rows, args.quota_b)))

    if targets:
        print("\n".join(check_counts(rows, targets)))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
