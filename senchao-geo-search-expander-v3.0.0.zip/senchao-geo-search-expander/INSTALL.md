# 安装说明（森潮GEO搜索拓词 v3.0.0 全域版）

这是一个 WorkBuddy 专家包。安装后，在 WorkBuddy 左侧「专家」入口的「我的专家」里就能看到「森潮GEO搜索拓词」。

## 方式一：让 WorkBuddy 自己装（推荐，不需要懂命令行）

1. 把 `senchao-geo-search-expander.zip` 解压，得到一个同名文件夹。
2. 打开 WorkBuddy，新建一个对话，把下面这句话连同文件夹路径一起发出去：

   > 帮我安装这个专家包：`<解压后的文件夹完整路径>`

3. WorkBuddy 会自动完成校验与注册。注册成功后，在「专家中心 - 我的专家」里刷新即可看到。

## 方式二：手动放置（熟悉文件目录的人用）

1. 把解压出来的 `senchao-geo-search-expander` 整个文件夹，放进本机的专家目录：

   ```
   Windows:  C:\Users\<你的用户名>\.workbuddy\plugins\marketplaces\my-experts\plugins\
   macOS:    ~/.workbuddy/plugins/marketplaces/my-experts/plugins/
   ```

   放好之后的路径应该是：

   ```
   ...\my-experts\plugins\senchao-geo-search-expander\.codebuddy-plugin\plugin.json
   ```

2. 运行注册脚本，让它在专家清单里登记（脚本随 WorkBuddy 一起安装，路径因安装位置而异，一般在 WorkBuddy 安装目录下的 `resources\plugins\workbuddy-builtin\skills\expert-manager\scripts\`）：

   ```bash
   python register_expert.py "<上面的专家文件夹完整路径>"
   ```

3. 重启 WorkBuddy，进「专家中心 - 我的专家」确认已出现。

## 装完怎么用

选中该专家，直接输入一家公司的全称、简称、官网网址或一段简介，例如：

> 帮我基于「XX 激光设备有限公司」生成 GEO 搜索词库。

它会交回一个 `geo-wordbank-XX.html` 单文件网页，双击即开，内含品牌词、品类词、业务词三类词库（目标 50 / 50 / 120，行业素材不足时会按实际数量交付并说明原因）、P0-P4 优先级与平台标签、13 平台分 3 族的收录分析、森潮五真体系对应、全域漏斗视图、竞品缺口清单，以及来源级别说明与抽检通过率。

网页里的复制按钮在本地双击打开时也能用（已做浏览器兼容兜底）。

## 包内结构

```
senchao-geo-search-expander/
├── .codebuddy-plugin/plugin.json          专家展示信息（名称、简介、标签、推荐提问）
├── agents/senchao-geo-search-expander.md   全部业务规则（组词公式、矩阵、红线、网页规范）
├── skills/senchao-geo-expander/
│   ├── SKILL.md                           拓词方法论（四层结构、九维辐射、战场改写）
│   ├── references/playbook.md             实战剧本（填空表、句式库、缺口排查流程）
│   └── scripts/expander_prep.py           词库去重与初分级工具
├── avatars/expert.png                     头像（512×512）
└── README.md                              能力说明
```

## 环境要求

- WorkBuddy 桌面版（专家功能可用）。
- 仅在用到 `expander_prep.py` 时需要一个可用的 Python 3 环境；不用这个脚本不影响专家正常工作。

## 说明

- 本专家为森潮全域科技自建版本，能力口径参考行业通行的 GEO 词汇挖掘方法，内容为原创撰写。方法论名称「森潮五真体系」归属森潮全域科技。
- 包内不含任何客户数据、账号信息或内部资料，可安全分发。
